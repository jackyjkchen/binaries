#include "sc_foo.h"
template <class Arg>
void sc_foo<Arg>::bar(Arg) {
}
