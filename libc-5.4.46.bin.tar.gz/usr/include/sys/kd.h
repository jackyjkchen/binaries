#ifndef _SYS_KD_H
#define _SYS_KD_H

#include <linux/kd.h>

#endif /* _SYS_KD_H */
