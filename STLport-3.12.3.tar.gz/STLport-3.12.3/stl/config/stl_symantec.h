// STLport configuration file
// It is internal STLport header - DO NOT include it directly

// if not using maximum ANSI compatibility ( -A -Ab -Aw),
// comment the following two lines out:
#  define __STL_BOOL_KEYWORD 1
#  define __STL_WCHAR_T 1
#  define __STL_NON_TYPE_TMPL_PARAM_BUG 1
#  define __STL_USE_EXCEPTIONS 1
#  define __STL_DEFAULT_TEMPLATE_PARAM 1
// #  define __STL_BASE_MATCH_BUG          1
// #  define __STL_NONTEMPL_BASE_MATCH_BUG  1
#  define __STL_UNINITIALIZABLE_PRIVATE  1
// #  define __STL_BASE_TYPEDEF_OUTSIDE_BUG 1
#	define __STL_THROW_RETURN_BUG	1
