// STLport configuration file
// It is internal STLport header - DO NOT include it directly

#   define __STL_MEMBER_TEMPLATES
#   define __STL_MEMBER_TEMPLATE_CLASSES
#   define __STL_CLASS_PARTIAL_SPECIALIZATION
#   define __STL_USE_EXCEPTIONS
#   define __STL_DEFAULT_TEMPLATE_PARAM 1
#   define __STL_METHOD_SPECIALIZATION
