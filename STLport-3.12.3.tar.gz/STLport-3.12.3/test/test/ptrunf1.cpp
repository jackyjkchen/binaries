#ifndef SINGLE
//  An adapted ObjectSpace example for use with SGI STL

#include <iostream.h>
#include <algo.h>

#ifdef MAIN 
#define ptrunf1_test main
#endif
bool even(int n_)
{
  return(n_ % 2) == 0;
}
#endif
int ptrunf1_test(int, char**)
{
  cout<<"Results of ptrunf1_test:"<<endl;

int array [3] = { 1, 2, 3 };

  int* p = find_if((int*)array, (int*)array + 3, 
    pointer_to_unary_function<int, bool>(even));
  if(p != array + 3)
    cout << *p << " is even" << endl;
  return 0;
}
