#ifndef SINGLE
//  An adapted ObjectSpace example for use with SGI STL

#include <vector.h>
#include <algo.h>
#include <iterator.h>
#include <iostream.h>

#ifdef MAIN 
#define adjdiff1_test main
#endif
#endif
int adjdiff1_test(int, char**)
{
  cout<<"Results of adjdiff1_test:"<<endl;
  vector <int> v(10);
  for(int i = 0; i < v.size(); i++)
    v[i] = i * i;
  vector <int> result(v.size());
  adjacent_difference(v.begin(), v.end(), result.begin());
  ostream_iterator<int> iter(cout, " ");
  copy(v.begin(), v.end(), iter);
  cout << endl;
  copy(result.begin(), result.end(), iter);
  cout << endl;
  return 0;
}
