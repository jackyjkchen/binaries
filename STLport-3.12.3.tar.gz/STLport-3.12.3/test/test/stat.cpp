#ifndef SINGLE
//  An adapted ObjectSpace example for use with SGI STL
#ifdef MAIN 
#define stat_test main
#endif
#endif
#define __PUT_STATIC_DATA_MEMBERS_HERE
// #include <stl.h>


